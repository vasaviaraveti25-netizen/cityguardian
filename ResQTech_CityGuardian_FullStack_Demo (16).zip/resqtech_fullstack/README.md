# CityGuardian AI — ResQTech Full-Stack Prototype

A runnable local prototype for the CityGuardian AI hackathon project. It includes a React/Vite frontend, FastAPI backend, SQLAlchemy persistence, and support for either SQLite (default) or PostgreSQL.

> **Safety:** This is a demonstration only. Incident records, ambulances, and hospital notifications are simulated. It does not contact emergency services, provide clinical triage, perform real dispatch, or connect to live hospital/smartwatch systems. Do not enter real patient information or expose this prototype publicly. In India, call **112** for actual emergencies.

## Requirements
- Python 3.10+
- Node.js 18+
- Optional: Docker Desktop for PostgreSQL

## 1. Start the backend (SQLite easiest)

Windows PowerShell:
```powershell
cd backend
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload
```

macOS/Linux:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

API docs: http://127.0.0.1:8000/docs
Health check: http://127.0.0.1:8000/api/health

By default, SQLAlchemy creates `backend/resqtech.db` automatically. No separate database setup is required.

## 2. Optional PostgreSQL setup

From the project root, start PostgreSQL using Docker:
```bash
docker compose up -d postgres
```

Set the environment variable before starting the backend.

Windows PowerShell (from `backend`):
```powershell
$env:DATABASE_URL="postgresql+psycopg://postgres:change_this_local_password@localhost:5432/cityguardian"
uvicorn main:app --reload
```

macOS/Linux (from `backend`):
```bash
export DATABASE_URL="postgresql+psycopg://postgres:change_this_local_password@localhost:5432/cityguardian"
uvicorn main:app --reload
```

The backend will create the prototype tables on startup. For production, replace `create_all` with versioned migrations, use strong credentials, and configure backups and network access appropriately. Never commit production secrets.

## 3. Start the frontend

Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```

Open http://127.0.0.1:5173

## 4. Demonstration workflow

1. Select **Report Incident** and submit a synthetic incident.
2. Return to the dashboard and select **Review** to set priority.
3. Select **Assign** and choose an available demo ambulance ID.
4. Select **Notify** and enter a demo hospital name.
5. Open **Hospitals** and acknowledge the notification.
6. Open the incident timeline to see persisted workflow events.

## API endpoints
- `GET /api/health`
- `GET/POST /api/incidents`
- `PATCH /api/incidents/{id}/review`
- `POST /api/incidents/{id}/assign`
- `POST /api/incidents/{id}/notify`
- `GET /api/ambulances`
- `GET /api/notifications`
- `POST /api/notifications/{id}/acknowledge`
- `GET /api/incidents/{id}/timeline`

## Current limitations
- No user authentication or role-based authorization yet.
- AI triage is not connected; priority is entered during operator review.
- Ambulance assignment, route planning, hospital notifications, and device alerts are simulated.
- No live Google Maps, live GPS, Bluetooth, or real dispatch.
- This is a hackathon starter, not a production-ready emergency platform.
