from datetime import datetime, timezone
from pathlib import Path
import os
from typing import Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv('DATABASE_URL', f"sqlite:///{Path(__file__).with_name('resqtech.db')}")
engine_args = {'pool_pre_ping': True}
if DATABASE_URL.startswith('sqlite'):
    engine_args['connect_args'] = {'check_same_thread': False}
engine = create_engine(DATABASE_URL, **engine_args)
Session = sessionmaker(bind=engine)
Base = declarative_base()

def now(): return datetime.now(timezone.utc)

class Incident(Base):
    __tablename__='incidents'
    id=Column(Integer,primary_key=True)
    category=Column(String(50),nullable=False)
    description=Column(Text,nullable=False)
    location=Column(String(200),nullable=False)
    priority=Column(String(20),nullable=False,default='Pending review')
    status=Column(String(40),nullable=False,default='Reported')
    ambulance_id=Column(Integer,ForeignKey('ambulances.id'),nullable=True)
    created_at=Column(DateTime(timezone=True),default=now)
class Ambulance(Base):
    __tablename__='ambulances'
    id=Column(Integer,primary_key=True)
    name=Column(String(60),nullable=False,unique=True)
    status=Column(String(30),nullable=False,default='Available')
class Notification(Base):
    __tablename__='notifications'
    id=Column(Integer,primary_key=True)
    incident_id=Column(Integer,ForeignKey('incidents.id'),nullable=False)
    hospital=Column(String(120),nullable=False)
    status=Column(String(30),nullable=False,default='Pending')
class Event(Base):
    __tablename__='events'
    id=Column(Integer,primary_key=True)
    incident_id=Column(Integer,ForeignKey('incidents.id'),nullable=False)
    message=Column(String(240),nullable=False)
    created_at=Column(DateTime(timezone=True),default=now)
Base.metadata.create_all(engine)
with Session() as db:
    if not db.query(Ambulance).first():
        db.add_all([Ambulance(name='DEMO-AMB-01'),Ambulance(name='DEMO-AMB-02'),Ambulance(name='DEMO-AMB-03')]); db.commit()

app=FastAPI(title='ResQTech CityGuardian AI Demo API')
app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173','http://127.0.0.1:5173'],allow_methods=['*'],allow_headers=['*'])
class NewIncident(BaseModel):
    category:str=Field(min_length=2,max_length=50)
    description:str=Field(min_length=5,max_length=2000)
    location:str=Field(min_length=3,max_length=200)
class Review(BaseModel): priority:str
class Assignment(BaseModel): ambulance_id:int
class HospitalNote(BaseModel): hospital:str=Field(min_length=2,max_length=120)

def incident_dict(i):
    return dict(id=i.id,category=i.category,description=i.description,location=i.location,priority=i.priority,status=i.status,ambulance_id=i.ambulance_id,created_at=i.created_at.isoformat() if i.created_at else None)
def add_event(db, incident_id, message): db.add(Event(incident_id=incident_id,message=message))
@app.get('/api/health')
def health(): return {'ok':True,'mode':'SIMULATION - NOT CONNECTED TO EMERGENCY SERVICES'}
@app.get('/api/incidents')
def incidents():
    with Session() as db: return [incident_dict(i) for i in db.query(Incident).order_by(Incident.id.desc()).all()]
@app.post('/api/incidents',status_code=201)
def create_incident(data:NewIncident):
    with Session() as db:
        i=Incident(**data.model_dump());db.add(i);db.flush();add_event(db,i.id,'Incident reported (demo)');db.commit();db.refresh(i);return incident_dict(i)
@app.patch('/api/incidents/{incident_id}/review')
def review(incident_id:int,data:Review):
    if data.priority not in ['Low','Medium','High','Critical']:raise HTTPException(422,'Invalid priority')
    with Session() as db:
        i=db.get(Incident,incident_id)
        if not i:raise HTTPException(404,'Incident not found')
        if i.status!='Reported':raise HTTPException(409,'Incident already reviewed')
        i.priority=data.priority;i.status='Under Review';add_event(db,i.id,f'Operator demo review: {data.priority}');db.commit();return incident_dict(i)
@app.get('/api/ambulances')
def ambulances():
    with Session() as db:return [{'id':a.id,'name':a.name,'status':a.status} for a in db.query(Ambulance).all()]
@app.post('/api/incidents/{incident_id}/assign')
def assign(incident_id:int,data:Assignment):
    with Session() as db:
        i=db.get(Incident,incident_id);a=db.get(Ambulance,data.ambulance_id)
        if not i or not a:raise HTTPException(404,'Incident or ambulance not found')
        if i.status!='Under Review':raise HTTPException(409,'Incident must be reviewed and unassigned')
        if a.status!='Available':raise HTTPException(409,'Ambulance unavailable')
        a.status='Assigned';i.ambulance_id=a.id;i.status='Ambulance Assigned';add_event(db,i.id,f'Simulated assignment: {a.name}');db.commit();return incident_dict(i)
@app.post('/api/incidents/{incident_id}/notify')
def notify(incident_id:int,data:HospitalNote):
    with Session() as db:
        i=db.get(Incident,incident_id)
        if not i:raise HTTPException(404,'Incident not found')
        if i.status!='Ambulance Assigned':raise HTTPException(409,'Assign an ambulance first')
        n=Notification(incident_id=i.id,hospital=data.hospital);db.add(n);db.flush();i.status='Hospital Notified';add_event(db,i.id,f'Simulated hospital notification: {data.hospital}');db.commit();return {'id':n.id,'status':n.status}
@app.get('/api/notifications')
def notifications():
    with Session() as db:return [{'id':n.id,'incident_id':n.incident_id,'hospital':n.hospital,'status':n.status} for n in db.query(Notification).order_by(Notification.id.desc()).all()]
@app.post('/api/notifications/{notification_id}/acknowledge')
def acknowledge(notification_id:int):
    with Session() as db:
        n=db.get(Notification,notification_id)
        if not n:raise HTTPException(404,'Notification not found')
        n.status='Acknowledged';add_event(db,n.incident_id,f'Simulated hospital acknowledgement: {n.hospital}');db.commit();return {'id':n.id,'status':n.status}
@app.get('/api/incidents/{incident_id}/timeline')
def timeline(incident_id:int):
    with Session() as db:return [{'message':e.message,'created_at':e.created_at.isoformat() if e.created_at else None} for e in db.query(Event).filter_by(incident_id=incident_id).order_by(Event.id).all()]
